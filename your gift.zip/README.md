
  # your gift

  This is a code bundle for your gift. The original project is available at https://www.figma.com/design/qQueVWeNzNEMssOeW6ltoO/your-gift.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  